<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::get('btn','Controller@btncheck');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('reg','Controller@reg');
Route::post('/registered','Controller@registered');
Route::get('reg2','Controller@reg2');
Route::post('/registered2','Controller@registered2');
Route::get('reg3','Controller@reg3');
Route::post('/registered3','Controller@registered3');
Route::get('reg4','Controller@reg4');
Route::post('/registered4','Controller@registered4');
Route::get('/send/send_feedback', 'Controller@sendFeedback');
