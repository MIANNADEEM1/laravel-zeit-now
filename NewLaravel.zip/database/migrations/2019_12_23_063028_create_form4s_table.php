<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateForm4sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form4s', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->string('interaction');
            $table->string('Explain')->nullable();
          
         
            $table->string('festival__materials');
            $table->string('Previous');
            $table->string('Other')->nullable();
            $table->string('Previous_info')->nullable();
            $table->string('DropDown');/////
            $table->string('Surname');
            $table->string('First_name');
            $table->string('Contact_info');
            $table->string('Email')->unique();
            $table->string('condition1');
            $table->string('Condition2');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form4s');
    }
}
