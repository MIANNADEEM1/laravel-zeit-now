<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateForm3sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */ 
    public function up()
    {
        Schema::create('form3s', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->string('Teachername');
            $table->string('Schoolname');
            $table->string('Pemail')->nullable();
            $table->string('Pname')->nullable();
            $table->string('Pphone')->nullable();
            $table->string('Gender');
            $table->string('Schoollocation');
            $table->string('temail');/////
            $table->string('Tphone');
            $table->string('age');

            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form3s');
    }
}
