<!DOCTYPE html>
<html lang="en">
<head>
  <style>
    #san-button
    {
    padding: 10px 20px;
    background:#4CAF50;
    border: 0;
    color: #FFF;
    display:inline-block;
    margin-top:20px;
    cursor: pointer;
    }
    #san-button:disabled
    {
    padding: 10px 20px;
    background: #B9D8BA;
    border: 0;
    color: #FFF;
    display:inline-block;
    margin-top:20px;
    cursor: no-drop;
    }
    .validation-error
    {
    color:#FF0000;
    }
    .input-control
    {
    padding:10px;
    }
    .input-group
    {
    margin-top:10px;
    }
    </style>
  <title>registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  {{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> --}}
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="savy.min.js"></script>
  <script>
    function validate() {
    
    var valid = true;
    valid = checkEmpty($("#name"));
    valid = valid && checkEmail($("#email"));
    
    $("#san-button").attr("disabled",true);
    if(valid) {
    $("#san-button").attr("disabled",false);
    } 
    }
    function checkEmpty(obj) {
    var name = $(obj).attr("name");
    $("."+name+"-validation").html(""); 
    $(obj).css("border","");
    if($(obj).val() == "") {
    $(obj).css("border","#FF0000 1px solid");
    $("."+name+"-validation").html("Required");
    return false;
    }
    
    return true; 
    }
    function checkEmail(obj) {
    var result = true;
    
    var name = $(obj).attr("name");
    $("."+name+"-validation").html(""); 
    $(obj).css("border","");
    
    result = checkEmpty(obj);
    
    if(!result) {
    $(obj).css("border","#FF0000 1px solid");
    $("."+name+"-validation").html("Required");
    return false;
    }
    
    var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,3})+$/;
    result = email_regex.test($(obj).val());
    
    if(!result) {
    $(obj).css("border","#FF0000 1px solid");
    $("."+name+"-validation").html("Invalid");
    return false;
    }
    
    return result; 
    }
    </script> 

<script>
    $(document).ready(function(){
      $("#t").click(function(){
        $("#cf").html('<div id="rm"> <label for="name">Team member Name:</label><input type="text" class="form-control" name="tname[]" id="nm1"  required><label for="email">Team member Email:</label><input type="text" class="form-control" name="temail[]" id="em1" required><input id="btnAdd1" type="button" value=" + ADD more members"> &nbsp<input id="other" type="button" value=" -"><label>&nbsp &nbsp &nbsp Each team Member wiil be sent an email to join the personal details</label></div>');
      });
    
     
    });
    
    </script>
    
    <script>
   $(document).ready(function () {
     $(document).on('click','#rm #btnAdd1', function () {
      
         var newListItem = $('<div id="rm1"> <label for="name">Team member Name:</label><input type="text" class="form-control" name="tname[]" required><label for="email">Team member Email:</label><input type="text" class="form-control" name="temail[]" required></div>').on('click', function () {
            
         });

         $('#cf').append(newListItem);
     });
 });
</script> 
<script>
  function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.innerHTML === "Each Team Member will be sent an email") {
      x.innerHTML = "Each Team member will be sent an email!";
    } else {
      x.innerHTML = "Each Team member will be sent an email!";
    }
  }
  </script>
<script>
$(document).ready(function(){
  $("#i").click(function(){
    $("#rm").remove();
  });
});
$(document).ready(function(){
  $(document).on('click','#rm #other', function () {
    $("#rm1").remove();
  });
});
</script>
 <script>
  $(function() {  
 $('.auto-save').savy('load');
});
$(function() {  
 $( "#hello2" ).click(function() {
    $('.auto-save').savy('destroy');
  });
});
      </script>
</head>
<body>
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
@endif

<div class="container">
  <h2>Registration Form</h2>
  <form action="registered" method="post"  id="frm">
  <div class="form-group">
 
     <label> <div class="input-group">FirstName: <span class="name-validation validation-error"></span></div></label>
<div>
      <input type="text" class="auto-save form-control"  placeholder="Enter First name" name="FirstName"  id="name" onblur="validate()">
    </div>
  </div>
  <div class="form-group">
      <label for="LastName">LastName:</label>
      <div>
      <input type="text" id="ln" class="auto-save form-control"  placeholder="Enter Last name" name="LastName" required>
      </div>
    </div>
    <div class="form-group">
      <label for="Phone">Phone: Format: 0334-044-6789</label>
      <div>
      <input type="tel" class="auto-save form-control bfh-phone"  placeholder="Enter Phone Number" name="Phone"
        data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" id="tel" onchange="change_myselect(this.name)" required>
    </div>
    </div>
   
    <div class="form-group">
      <label for="dob">DateOfBirth:</label>
      <div>
      <input type="date"   class=" auto-save form-control" id="dob" name="DOB" required>
      </div>
    </div>
    <div class="form-group">
  <label for="Gender">Gender:</label>
  <select class="auto-save form-control"  name="Gender" required>
  <option required>Select Gender</option>
    <option>Male</option>
    <option>Female</option>
    <option>Other</option>
   
  </select>
</div>
<div class="form-group">
  <label for="Location">Location:</label>
  <select required  class="auto-save form-control"  name="Location" id="loc">
  <option required>Select LOCATION </option>
    <option>Abu Dhabi-Al Ain</option>
    <option>Abu Dhabi-Al Dhafra</option>
    <option>Abu Dhabi-City</option>
    <option>Ajman</option>
    <option>Dubai</option>
    <option>Fujairah</option>
    <option>Ras-al-Khaima</option>
    <option>Sharjah</option>
    <option>Umm-al-Quwain</option>
   
  </select>
</div>
    <div class="form-group">
    <label>  <div class="input-group">Email <span class="email-validation validation-error"></span></div> </label>
     <div>
      <input type="email" id="email" class="auto-save form-control"  placeholder="Enter email" name="email" onblur="validate()">
     </div>
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <div>
      <input type="password" id="pass" class="auto-save form-control"  placeholder="Enter password" name="password"  required>
    </div></div>
    <div class="form-group">
      <label for="Nationality">Nationality:</label>
      <div>
      <input type="text" class="auto-save form-control" placeholder="Enter nationality" id="nat" name="Nationality" required>
    </div></div>
    <div class="form-group">
      <label for="info">About Yourself:</label>
      <div>
      <textarea class="auto-save form-control" rows="5"  name="info" id="ab" required></textarea>
    </div>
  </div>
    <br>
    <label> Are you an individual Innovator or Team of Innovators</label>
    <div class="form-check">
      <label class="form-check-label" for="radio2"> 
        <div>
        <input type="radio" class=" form-check-input" id="i" name="members" value="individual" required>Individual: </label>
        </div>
    </div>
   
    <div class="form-check" id="">
      <label class="form-check-label" for="radio2">
        <input type="radio" class=" form-check-input" id="t" name="members" value="team" required>Team
      </label>
    </div>
    <div class="container-fluid" id="cf">

    </div>
    <div class="container-fluid" id="cf1">

    </div>



    <br>
    <input type="hidden" name="_token" value="{{ csrf_token()}}">
    <div>
      <button type="submit" name="btn-submit" id="san-button" disabled="disabled" onclick="myFunction()">Create Account & Send Invites</button>
      <button  class="btn btn-danger destroy" id="hello2">Destroy Local Storage</button>
      </div>
      <div id="myDIV"></div>
    <label>
    
  </form>
</div>

</body>
</html>
