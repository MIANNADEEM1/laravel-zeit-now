<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   

    
 <script>  
 $(document).ready(function () {
     
    

     $('#btnAdd').on('click', function () {
        console.log( "You clicked a paragraph!" );
         var newListItem = $('<div id="rm"> <label for="usr">Name Of Orginaization:</label><input type="text" class="form-control" name="oname"><label for="email">Email Of Orginaization:</label><input type="text" class="form-control" name="oemail"><label for="contact">Contact Of Orginaization:</label><input type="text" class="form-control" name="ocontact"><input id="btnAdd1" type="button" value="Again"></div>').on('click', function () {
            
         });

         $('#hello').append(newListItem);
     });
 });


 //////////
</script>

<script>
$(document).ready(function () {
     $(document).on('click','#rm #btnAdd1', function () {
        console.log( "You clicked a paragraph!" );
         var newListItem = $('<div id="rm1"> <label for="usr">Name Of Orginaization:</label><input type="text" class="form-control" name="oname"><label for="email">Email Of Orginaization:</label><input type="text" class="form-control" name="oemail"><label for="contact">Contact Of Orginaization:</label><input type="text" class="form-control" name="ocontact"></div>').on('click', function () {
            
         });

         $('#hello').append(newListItem);
     });
 });

 </script>
<style>
    button{
        margin: 5px;

    }
    input[type="submit"] {
  background: #5cb85c;
  color: #fff;
  transition: background 600ms;
  cursor: pointer;
}

input[type="submit"]:disabled {
  background: #555;
  cursor: not-allowed;
}
    </style>
</head>
<body>
    
    <input id="btnAdd" type="button" value="Add data">
  
    <div class="container-fluid danger" id="hello">

    </div>



 
    <ul>
    <li>List Item</li>
    <li>List Item</li>
    </ul>
    <div class="container-fluid danger" id="hello1">

</body>
</html>