<!DOCTYPE html>
<html lang="en">
<head>
  <title> Form3</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script>
   $(document).ready(function(){
  $("#b").click(function(){
    $("#in").html('<div id="rm"> <label for="pm">Parent Name:</label><input type="text" class="form-control" name="Pname" id="Pname" required><label for="email">Parent Email :</label><input type="text" class="form-control" name="Pemail" id="Pemail" required><label for="contact">Parent Phone: Format: 0123-455-6789:</label><input type="tel"  class="form-control bfh-phone" name="Pphone" id="Pphone" data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" required></div>');
  });

 
});
$(document).ready(function(){
  $("#a").click(function(){
    $("#rm").remove();  
  });

 
});
    </script>
</head>
<body>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="container-fluid">
  <h2>Registration Form3</h2>
  <form action="registered3" method="post">
    <div class="container-fluid  bg-alert">
     <label> School/Educational Institution </label>
  <div class="form-group">
      <label for="gender">Gender:</label>
      <div>
      <label><input type="radio" value="Male"  name="Gender" >Male</label>
      <label><input type="radio" value="Female"  name="Gender">Female</label>
      </div>
    </div>
    
  <div class="form-group">
      <label for="LastName">Schoolname:</label>
      <div>
      <input type="text" class="form-control"  placeholder="Enter School name" name="Schoolname" required>
      </div>
    </div>
    <div class="form-group">
  <label for="Location">Location:</label>
  <select class="form-control"  name="Schoollocation" required>
  <option>Select LOCATION</option>
    <option>Abu Dhabi-Al Ain</option>
    <option>Abu Dhabi-Al Dhafra</option>
    <option>Abu Dhabi-City</option>
    <option>Ajman</option>
    <option>Dubai</option>
    <option>Fujairah</option>
    <option>Ras-al-Khaima</option>
    <option>Sharjah</option>
    <option>Umm-al-Quwain</option>
   
  </select>
</div>
<div class="form-group">
      <label for="teachername">Teachername:</label>
      <div>
      <input type="text" class="form-control"  placeholder="Enter Teacher name" name="Teachername" required>
      </div>
    </div>
    <div class="form-group">
      <label for="Phone">Phone: Format: 0123-455-6789</label>
      <div>
      <input type="tel" class="form-control bfh-phone"  placeholder="Enter Phone Number" name="Tphone"
        data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" required>
      </div>
    </div>
    <div class="form-group">
      <label for="email">Teacher Email:</label>
      <div>
      <input type="email" class="form-control"  placeholder="Enter email" name="temail" required>
      </div>
    </div>
    </div>
    
      <label>Parent/Guardian Information</label>
    <div class="form-check">
      <label class="form-check-label" for="radio2">
        
        <input type="radio" class="form-check-input" id="b" name="age" value="Below">Below:
       
      </label>
    </div>
    <div class="form-group" id="in">

      </div>
    <div class="form-check" id="">
      <label class="form-check-label" for="radio2">
        <input type="radio" class="form-check-input" id="a" name="age" value="Above">Above
      </label>
    </div>
   
    
   
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <button type="submit">Create</button>
  
    
  </form>
</div>




</body>
</html><?php /**PATH C:\xampp\htdocs\work\resources\views/form3.blade.php ENDPATH**/ ?>