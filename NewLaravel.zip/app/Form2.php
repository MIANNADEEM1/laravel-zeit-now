<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Form2 extends Model
{
    

    protected $fillable = [
        'ProjectName', 'ProjectDescription', 'ProjectCategory', 'image','link','REI','business', 
        'oname','oname1','oemail','oemail1','ocontact','ocontact1','members','temail','tname',
    ];


    protected $hidden = [
        'password', 'remember_token',
    ];


    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


}
